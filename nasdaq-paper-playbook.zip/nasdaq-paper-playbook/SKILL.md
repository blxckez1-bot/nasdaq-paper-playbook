---
name: nasdaq-paper-playbook
description: Research and review Nasdaq MNQ futures paper setups, causal signals, costs and risk. Use for setup plans, strategy validation or paper journals; never funded/live execution.
---

# Nasdaq paper playbook for Claude

Use a fixed, evidence-based research process for CME Micro E-mini Nasdaq-100 (MNQ). The default **MNQ-SR-HL-LONG-v0.2** hypothesis is **UNVALIDATED / NEW ENTRY WAIT**. Installation, synthetic checks, simulator games and profitable anecdotes do not establish an edge or authorize a trade. Do not promise a perfect setup, win rate, daily trade or profit.

## Choose the task

- **Research/validation:** read [strategy](references/strategy-v0.2.md) and [validation protocol](references/validation-protocol.md). Freeze data, rules, code, execution model, costs and all trials before outcomes. Preserve failed trials, skips and no-trade days. Research has no order side effects.
- **Active setup review:** read the strategy, [policy](references/operating-policy.json), [snapshot schema](references/snapshot-schema.md) and the user's actual private journal/configuration, if accessible. Gather fresh evidence and assess the causal signal before calculating a plan. Run `scripts/preflight.py` for arithmetic/checklist review. It cannot detect chart signals, inspect sources, validate performance or authorize orders.
- **Scheduled account check:** observe and journal only. Never submit, modify, cancel or close orders, change accounts/settings or buy data. Do not create a schedule unless requested. Stay quiet on unchanged routine state; report material verified activity or access/protection failures.
- **Broader daily research:** read [expansion overview](references/research-expansion/README.md). AM/PM long and short breakout/retest cohorts are separately specified, unvalidated experiments. They do not replace the default, create daily quotas, bypass gates or pass the long-only preflight.

## Claude tools and private state

This folder supplies instructions and an offline Python helper. It supplies no live feed, TradingView access, desktop controller, broker, API keys, scheduler or automatic signal engine. Use only tools actually available and authorized in the current Claude environment. Never invent access or infer a fill from a candle. If access is unavailable, state the specific missing capability and continue only the supported research work.

The distributed policy has `expected_account: null`; active review remains blocked until the user requests setup and the intended Paper Trading account is visibly verified and privately bound. Keep account identity, journals, cashflows, fills, screenshots and credentials outside public repositories. Locate existing records supplied in the current environment; preserve original equity, cashflows, losses, attribution and prior reviews. A new file, date or skill installation never resets account history. Do not assume the original author's workspace, account authorization or historical quote status transfers with the download.

For this workflow use TradingView Desktop for Windows, visible **Paper Trading**, the privately configured account and a current actual dated MNQ contract. No silent browser/account/instrument substitution, paid subscription/trial, credential collection or live/funded access. Existing human paper authorization in the current conversation can be honored within its scope; the skill itself grants none and creates no new blanket permission. A missing desktop tool means account inspection is unavailable, not that the account is flat.

## Fixed default and causal evidence

The canonical strategy specifies prior cash-session low, first sweep/reclaim, later structure break, frozen impulse, first qualifying higher-low midpoint retest and next-event entry reference. Follow its exact inequalities, first-event rules, warm-up, time windows, news exclusions, invalidation and frozen obstacles. All its parameters are unvalidated research conventions. No signal engine is implemented.

Rule timezone is America/New_York; store UTC and display Europe/Copenhagen with date-correct daylight time. Signals use only completed, actually available inputs. A two-right-bar pivot is known after the second right bar closes. Never use final-day extrema, later revisions, future mitigation or full-sample normalization. Extra FVG/SMT/VWAP/regime filters are separate registered experiments.

Timely verified quotes are required for short-term entries. A ten-minute delayed chart is ineligible even if the computer clock is current. Confirm higher-timeframe context, calendar/news over the entire intended holding window, support/resistance, ATR/volatility, spread/liquidity, dated contract/expiry and supervision. Missing evidence means WAIT.

## Risk and records

- One MNQ contract and one position maximum. USD2 per index point; 0.25-point tick is USD0.50. Verify current exchange specifications before an active plan.
- Default planning budget is 0.10% of freshly observed marked equity, including costs. Retain a minimum USD15 per-contract round-trip stress reserve; it is an assumption, not an actual charged fee or guaranteed loss bound. If one contract does not fit, skip.
- Use the structural stop, never a stop tightened for affordability. Do not widen an active stop, average down or increase size based on confidence, a loss, a game score or a profit aspiration.
- Check daily marked-equity loss against the documented 2.5% review trigger, plus prior tighter reviews and existing limits. It pauses proposed risk and prompts review; it does not instruct scheduled liquidation. Unknown daily starting equity/cashflows require reconciliation, not a reset.
- Require cost-adjusted target room under the canonical net2R rule, frozen obstacles, collateral and a native full-quantity stop/target plan. The separate ORB control retains its own gross2R policy. Do not confuse these rules.
- Record a plan, submitted order, working order and confirmed fill separately. Reconcile by IDs/times, quantities, status, prices and cashflows. Working orders and inactive stops are not fills; a UI label is not fee evidence. Preserve adverse fills/execution deviations and distinguish realized/unrealized PnL from modeled reserves.

## Offline helper

Python 3.9+ with IANA timezone data is required; no third-party Python library or network connection is used. If timezone data is unavailable, the helper returns WAIT; do not silently install dependencies. Choose a new output outside the installed skill:

```text
python scripts/preflight.py --snapshot /private/evidence.json --output /private/decision-new.json
```

The helper checks the packaged specification hash and blocks missing/old quotes, unconfigured or wrong account, unsupported direction, risk or evidence failures. It refuses overwrites and always emits `order_authorized: false`. A synthetic reviewable fixture is not a market result. Initial validation is NOT_EVALUATED; changing a status string is not historical validation. A genuine reviewed report must bind the same packaged rule hash before a versioned pilot review. Later forward evidence is needed for continuation; no stage grants live authority.

[Adaptation notes](references/skill-adaptations.md) describe cost, causality and futures-specific pitfalls. These methods are self-contained; installing other named skills is optional and cannot supply missing market evidence. [Provenance](references/provenance.json) distinguishes the portable hash from the unchanged private source specification.
