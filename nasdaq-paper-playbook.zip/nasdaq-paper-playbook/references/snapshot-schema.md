# Preflight evidence snapshot

This helper checks a proposal, not the external evidence or chart pattern itself. Inspect sources before attesting. Unknown fields remain null/false. No result authorizes an order.

- `mode`: active, research or scheduled. Only active can yield a reviewable proposal.
- `symbol`: actualCME_MINI:MNQ+H/M/U/Z+four-digityear; `direction`: LONG.
- `account`: `id` exactly the privately configured `expected_account`; `mode` exactlyPaper Trading; timezone-awareISO`observed_at`; positive`equity`; integer`positions`0,`pending_orders`0. Never refresh a historical observation by changing its timestamp.
- `quote`: timezone-awareISO`observed_at`and`market_timestamp`; positive`bid`/`ask`; `real_time`true; numeric`delay_seconds`0. The market timestamp is not a candle-start label or only the computer clock.
- `plan`: tick-aligned`entry_reference`,`stop`,`target`,`cost_reserve_per_contract_usd`,`contract_expiry`. Levels follow the canonical evidence, not affordability.
- `checks`: each required key contains`verified`exactlytrue and nonempty`evidence`describing the observation/artifact. These are attestations, not independent validation.

Required keys: correct_account, contract_specs, cash_calendar, news_and_holding_window_clear, higher_timeframe_context, causal_signal, frozen_resistance, volatility_liquidity_spread, costs_not_double_counted, collateral, account_day_review_clear, prior_review_resolved, native_protection_plan, active_supervision, paper_scope.

News clearance requires no listed high-impact release in the intended entry/holding interval withv0.2buffers. Causal-signal evidence cites completed bars, availability times and frozen levels. Daily-review evidence preserves starting/cumulative equity and cashflows. Missing known state cannot become a pass through a new empty record.

The installed policy binds the specification hash and validation state. Updating a snapshot cannot change the policy or manufacture historical testing. The initial status isNOT_EVALUATED. A reviewed historical report meeting the protocol can setHISTORICAL_REVIEW_COMPLETE_PAPER_PILOT for an active forward-paper review. Later forward evidence can setFORWARD_REVIEW_COMPLETE_PAPER_CONTINUATION. Each report must bind to the same rule hash; neither status authorizes an order or proves future profitability. Do not require forward fills before the first historically reviewed pilot, or invent forward results to unlock it. Synthetic fixtures are not validation reports.


The distributed policy has `expected_account: null` and returns `paper_account_not_configured`. During an explicitly requested account setup, bind a verified Paper Trading account in the private installed copy only. Never commit the account identifier to GitHub. A missing snapshot ID cannot match an unconfigured account. Configuring an account does not satisfy validation or grant trading authority.
