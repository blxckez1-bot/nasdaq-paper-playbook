# Nasdaq research validation protocol v0.2

24 October 2026. This is a prospective research protocol, not completed testing or an account-policy amendment. Numerical acceptance conventions are deliberately stated before results and are not universal thresholds for profitable trading.

## Candidate registry and comparisons

Register every tested rule version, code hash, dataset hash, dates, parameters, costs and reason for trying it. Retain failures. Initial registry:

| ID | Purpose | Definition / status |
|---|---|---|
| SR-HL-v0.2 | User-material challenger | Long sweep/reclaim, later structure confirmation, first higher-low midpoint retest. Full rules in strategy-v0.2.md. Unvalidated. |
| ORB-15-v0.1 | Simple independent baseline | Freeze 09:30-09:45NY high/low after three completed5m bars. At09:45 freeze B using the primary's WilderATR convention on the just-completed09:40-09:45bar. First subsequent close above ORhigh+tick or below ORlow-tick until10:30; inspect the next available opening/quote event and submit only after the primary's declared latency sequence. Long stop=floor(ORlow-B), short stop=ceil(ORhigh+B). Before submission freeze a gross2Rtarget from the pre-submit entry reference and this stop; do not redraw it from a later actual fill. Flat11:00, no new entry at/after10:55. At most the first signal/day. Costs, one-contract budget and retention of adverse fills follow the challenger. The ORBcontrol does NOT inherit the challenger'snet2Rpost-fill exit condition: its own predeclared target isgross2Rand netRwill be smaller aftercosts. Close an ORBexecution deviation for invalid stop/target ordering, time or risk-budget breach, not merely because netRR<2. No retest/HTF/FVG filter. Gross2R is a declared baseline, not advertised as net2R. |
| NO-TRADE | Cash baseline | Zero futures exposure, zero trading PnL; data/software costs separately disclosed. |
| Fixed-session long/short | Directional controls | Fixed09:45next-event entry and11:00exit on eligible days, separately long and short. OneMNQ, same fees, no hindsight direction; report gross/net and full equity. These exposure controls have no matching structural stop and are not risk-normalized alternatives or authorized account trades. |
| CLOSING-MOMENTUM | Separate later research | Literature-motivated15:30-16:00NY predictor. Not currently a specified or run strategy; do not count a citation as a tested candidate. |

Do not allocate between challenger and baseline using future performance, the completed day's range or the day's eventual trend label. A regime router is an additional model requiring its own prospective definition and untouched evaluation.

## Data contract

Obtain legally usable datedMNQ OHLCV with UTC start/end, symbol/instrumentID, event/availability timing, volume, source and correction policy. For execution assessment also obtain bid/ask/trades or finer bars. NQ data can assist long-horizon hypothesis discovery but cannot substitute for MNQ spread, fees, queue or fills. No data subscription is bought under this protocol.

Prefer at least five years spanning different volatility/trend conditions when available, rather than a selected winning month. If fewer years or observations are available, label that shortfall and keep the result exploratory. Do not synthesize pre-launchMNQ data or silently extend its history withNQ while claiming identical execution.

Validate: finite prices, high>=max(open,close), low<=min(open,close), high>=low, nonnegative volume, tick grid, duplicate/unsorted timestamps, timezone-awareness, bar duration, missing intervals, corrections, stale sequences and outliers. Investigate gaps against exchange holidays, halts, maintenance and no-trade intervals; a missing provider bar is not automatically a zero-volume candle. Preserve flags and a rejection manifest instead of filling across outages. OHLCV may be stamped at interval START; never treat that timestamp as the completed bar's availability. [Databento OHLCV conventions](https://databento.com/docs/schemas/ohlcv).

Select the active dated contract using an explicit rule known before the session, such as previous completed-session volume, with a documented expiry cutoff. Store the actual mapping. Use no same-day total volume to choose that morning's contract. Recompute prior-session levels on the selected contract; never create a rollover return by jumping between raw contract closes.

Adjusted continuous series may be useful for selected analytical features, but executions, margin and PnL use actual contract prices. Document adjustment vintage; later rolls can rewrite historical levels. Intraday raw per-contract testing with explicit session mapping is valid and need not be back-adjusted. [Databento continuous symbology](https://databento.com/docs/examples/symbology/continuous?lang=python), [TradingView back-adjustment](https://www.tradingview.com/support/solutions/43000685266-how-can-i-enable-backadjustment-for-continuous-futures/).

## Time and causal checks

- Rule timezoneAmerica/New_York; displayEurope/Copenhagen; UTC storage. Use an exchange calendar for holidays/early closes and actual timezone transitions.
- Signal is knowable only after its final input closes/arrives. A two-right-bar pivot is available at the second right-hand bar's close, not at the central bar. A three-barFVG is known after bar3closes, not atbar2.
- Compute features separately on each available data prefix and verify previously emitted, already-confirmed signals do not change when later data are appended.
- No final-day highs/lows, future mitigation labels, centered rolling windows, revised futureCOT availability, full-sampleATR normalization or hindsight regime labels in entry features.
- A news backtest uses the calendar known at that date. Tag hindsight classifications as analysis only. Official BLS/Fed calendars are sources, not complete coverage of unscheduled events. [BLS](https://www.bls.gov/schedule/), [Federal Reserve](https://www.federalreserve.gov/newsevents/calendar.htm).

## Costs and execution realism

Use one event-driven engine for final replay, with its version pinned and fill defaults overridden. NautilusTrader is the selected execution-research candidate; LEAN is a viable alternative, not a second engine whose best result is cherry-picked.

Declare per-side broker, exchange and regulatory fees; spread paid at execution; additional adverse slippage; latency; limit non-fills; order rejections; volume/queue constraints; stop gaps and liquidation limits. Separate the observed pre-submit reference from the later actual fill: a filled order that violates projected risk/target space must be retained as an execution deviation, not retrospectively dropped. If entry/exit quotes already embed spread, do not deduct the same spread again as an independent fee. A per-contract round-trip reserve is a budget assumption and is never recorded as an actual charged commission.

The existing plan's illustrative base wasUSD1.50commission per side plus2ticks per side, implyingUSD5roundtrip forMNQ. ItsUSD15stressreserve is not a verified fee quote or worst-case bound. Start with these only as labeled scenarios; recalibrate from provider/broker evidence. Repeat with materially higher friction, such as2x/3xbase and theUSD15scenario, plus explicit gap/rejection scenarios. Do not apply stock weight/bps or short-stock borrowing formulas to futures by default.

Record raw fill PnL and explicit fees separately. The correct contract PnL is direction*quantity*multiplier*(exit-entry), then actual/model costs as appropriate. Include marked equity while exposed, not only closed winners. Missing exit data is a failure, not a reason to omit a trade.

## Chronological design and uncertainty

Before calculating outcomes, lock date boundaries from the available manifest. Initial convention: earliest60%of full sessions for development, next20%for validation, newest20%sealed. Whole sessions stay together. Publish exact dates before running; do not keep reopening the sealed portion to improve the rule. Additional expanding/rolling walk-forward folds stay inside the development/validation portion. Purge overlapping trade/label horizons at boundaries; use only past training for a forward simulation. An embargo is not a cure for training on future data.

Aim for at least200out-of-sample trades across at least100distinctsessions, preferably a broader multi-year record; this is a research sufficiency convention, not a statistical guarantee. A rare method may need a longer history.30trades can detect gross process issues but cannot substantiate a small edge. Do not loosen rules merely to hit a sample count.

Report trade count, eligible/skip days, net expectancy inUSD andR, win rate with an uncertainty interval, average win/loss, profit factor, daily returns, equity/drawdown, worst day/trade, expected shortfall, consecutive losses, turnover, exposure and fees. Include the initial equity baseline when computing drawdown. Mark-to-market daily returns include all sessions, including no-trade days. Do not annualize irregular trade outcomes as if they were independent daily returns.

Estimate expectancy uncertainty with a day/block bootstrap that respects clustering; report sensitivity to block length and regime concentration. Wilson intervals for win rate are descriptive under independent Bernoulli assumptions and do not prove independence or account profitability. Keep long/short and regimes separate. Disclose that observations are conditional on the strategy and can change with market structure.

Track all trials, including abandoned filters. Use multiple-testing/selection diagnostics where enough comparable trials exist. A smallPBO or deflatedSharpe statistic does not override flawed data, an inspected holdout or unsuitable execution assumptions. [Bailey m.fl., Probability of Backtest Overfitting](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf).

## Proposed research acceptance criteria

All of the following are required to progress to an **active review of paper eligibility**, not to certify an edge or activate orders:

1. Complete data/causality and execution audits; no unresolved leakage, omitted losses, duplicate exposure or unsupported fill assumption.
2. Adequate stated sample/history coverage; positive net expectancy whose day/block-bootstrap95%lower bound is above0in the untouched test. Failure or an interval crossing0means inconclusive/reject, not a request for higher leverage.
3. Net profit factor>=1.20under declared base costs and>1under2xcosts; no reliance on only a few exceptional days. These cutoffs are preregistered screening choices, not universal profitable values.
4. The strategy remains viable across predeclared nearby settings; no narrow optimum. Stress ATRbuffer and timing modestly on development data, register every variation, and do not retune on the sealed test.
5. Drawdown, tail and worst-loss behavior at0.10%planning risk fit the unchanged operating review limits. Publish those limits from the actual current plan at test start. No new numeric account threshold is silently introduced. Simulated stop risk is not a maximum-loss guarantee.
6. Compare against no-trade and simple directional/ORB controls. A more complex challenger must earn its complexity on new data. If differences are inconclusive, prefer the simpler rule or remain unallocated.

Then freeze code/rules/costs and conduct at least30completed forward paper round-trips over at least20sessions, whichever takes longer, recording all non-entry observations separately, to inspect signal timing, actual rejects/non-fills, costs and rule compliance. This operational sample is not proof of stable profitability. Compare against the backtest distribution, investigate deviations, and retain skips. New configurations require a new version and additional independent evaluation.

## Ablations, adoption and current outcome

Only after core testing: test one optional addition at a time, e.g.confirmed15mstructure, three-completed-barFVG, sessionVWAP, synchronizedES/NQdivergence or past-onlyvolume. Declare algorithms, timestamps, parameters and multiple-testing cost first. Correlated confluences are not independent votes. COT/seasonality and closing momentum belong to separately timed research rather than a mandatoryminutetradingstack.

Current outcome: **historical performance NOT EVALUATED**; qualifying data and execution evidence are absent. The12synthetic helper tests check implementation arithmetic/causality only. No backtest returns, historical win probability, expected account gains or new entries are produced. The user's subscription refusal, live-account boundary and scheduled read-only checks remain unchanged.
