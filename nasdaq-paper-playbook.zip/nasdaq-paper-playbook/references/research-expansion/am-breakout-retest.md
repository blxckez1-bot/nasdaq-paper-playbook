# MNQ-OR15-BRT-AM-v0.1

## Identity and hypothesis

Defined 26 October 2026. **SPECIFIED / UNVALIDATED / RESEARCH ONLY.** CME dated MNQ, standard five-minute OHLCV; one contract maximum. This bidirectional breakout/retest family hypothesizes that the first successful retest after an opening-range break may continue toward a one-range extension. It is an initial falsifiable convention, not an established profitable effect.

All [common rules](common-rules.md) apply. Long and short are separate registered strata, not a rule to choose whichever historical direction worked.

## Entry rules

- Reference range is exactly the three bars covering 09:30:00–09:45:00 America/New_York, with close/end times 09:35, 09:40 and 09:45. Freeze H, L, W and B only after the last range bar closes and is available.
- Eligible first-breakout bars end from 09:50 through 10:30 inclusive.
- Use the first qualifying directional breakout and the first touch in its next three consecutive five-minute bars; that first touch must itself qualify under the common rules. Missing bars, invalidation or a failed first touch exhaust this AM cohort for that day.
- The reference quote and dispatch occur after retest availability and declared latency. The pre-submit event, submission and fill must all occur strictly before 10:55. A filled order at/after the cutoff is retained as an execution deviation and exited under the registered model; it is not erased.
- Native Paper Trading market-entry review is only a later eligible mode; this document sends no order and assumes no fill at a bar close or prior touch.

## Exits

Stop is the retest low minus B for long, or retest high plus B for short, rounded outward to ticks. Target is the one-range extension capped by the frozen nearest obstacle; net reward/risk must be at least 2 before submission. See exact equations in common rules. No partial exits, trailing, averaging down, discretionary signal exit or stop widening.

Hard stop takes priority over an ambiguous same-event target. No exposure remains after 11:00: exit at the first executable event at/after 11:00 with costs. Missing exit data is a replay failure, not a zero-PnL day. A target requires the predeclared execution/queue model; touch is not guaranteed execution.

These are prospective research exits. They do not restore historical arbitrary minute timers for existing orders or empower scheduled account checks to act.

## Sizing, filters and account limits

Use the common one-MNQ, 0.10%-of-current-equity cost-aware sizing, structural stop, separate collateral check and unchanged account review limits. Reject an unaffordable position. Require a normal full cash day and an immediately preceding normal full cash session on the same dated contract with complete reference history. Calendar, data, quote freshness, active supervision and native-protection gates all apply.

For the operational event screen, exclude a new entry if any listed high-impact event lies in the entry-to-11:00 interval inclusive or entry is within ten minutes before/after that event. No ad hoc exclusion based on the eventual day's trend or outcome.

## Evaluation, dependencies and lifecycle

Apply [validation-and-selection.md](validation-and-selection.md), realistic per-contract costs and the frozen original validation protocol. Required data, simulation engine configuration and calendar are not yet available. Backtest/OOS/forward-paper metrics, trade frequency and win probability are **not available**. Code implementation, execution-policy support and paper adoption are pending; no live stage is authorized.

Continue research only if data/causality/execution audits and the preregistered sample, uncertainty, cost and risk criteria pass. Inconclusive results remain inconclusive; failure retires or versions the hypothesis with a new holdout. Choppy breaks, deep or failed retests, oversized stops and insufficient target room are explicit failure modes. Version 0.1 is the initial specification, with no historical outcomes calculated.
