# Validation and daily selection v0.1

26 October 2026. **No market-data test has been run.** These are registered design choices before new outcomes. The 26 October chart has already been viewed; earlier observations from that day cannot be portrayed as an untouched prospective sample.

## Separate strategies and evidence

Retain the original frozen SR-HL-LONG-v0.2 rules and history. The portable edition has its own disclosed document hash; it does not replace or validate the original. The new AM and PM breakout/retest documents create four strata: AM-long, AM-short, PM-long, PM-short. The combined selection rule below is an additional tested configuration. Register every new parameter variant and any tested pooling; this list is not a claim that the project's total historical trial count is only five.

The original ORB-15-v0.1 control stays a separate gross2R, whole-range-stop baseline. It is not this first-retest/structural-stop/net2R candidate. Preserve no-trade and fixed-direction controls. Previously considered closing momentum, mirrored SR short, VWAP, FVG, SMT and discretionary regime routing remain deferred, rather than silently entering this family.

[Tsai et al.](https://scholars.lib.ntu.edu.tw/entities/publication/d69ecf33-892c-4f8a-9a88-2af1bcc4efcd) study opening-range rules on index futures including Nasdaq. That motivates investigating an alternative to the sweep setup; it does not validate these 15-minute/retest/net2R rules. Their best probing intervals were selected from tested values, and their cost convention differs from a present MNQ bid/ask execution model. The afternoon 13:00 anchor and one-width target are our untested conventions. No daily trade rate, return or win probability is inferred from the paper.

[Bailey et al.](https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf) explain selection bias across many tested configurations. We therefore keep this expansion small, retain failures, separate sides/windows and test the combined arbitration itself.

## Deterministic composite research selection

1. Evaluate every registered cohort independently and preserve its first breakout/touch outcome, including rejected/blocked cases. Independent shadow ledgers may show overlapping theoretical trades; those ledgers are not a jointly executable account or additive portfolio profit.
2. For the composite, a candidate is actionable only at its first pre-submit quote event after known-at plus decision latency, and only after all shared gates pass. Order candidate events by that event timestamp, not by eventual PnL or central pivot time.
3. The earliest fully qualified candidate while flat with no pending entry is selected. An earlier failed gate does not create a resting/queued entry. A cohort's exhausted candidate cannot be revived after a later favorable price.
4. Simultaneous same-direction SR-HL and AM candidates have fixed priority SR-HL, then the new family. Log the alternative as blocked, not a second fill. Simultaneous opposing directions are all skipped as conflict; no hindsight direction is chosen.
5. While a position or pending entry exists, later candidates are logged as exposure-blocked and not queued. Only a later independently formed candidate after flat can be evaluated. The first-breakout/first-touch cap is a research-cohort definition, not reinstatement of an obsolete two-attempt operating rule. No trade/day minimum or confidence-based increase exists.
6. Morning PnL never selects the afternoon rule, changes its side/thresholds or resets the daily loss calculation. Any future regime router, ranking score or performance-driven allocation is a different registered model.

## Data and chronological test protocol

Inherit the full frozen [original protocol](../validation-protocol.md): legally usable actual dated MNQ history, known-time availability, explicit contract selection/roll mapping, complete full sessions/overnight/warm-up, independent calendar, realistic per-contract execution and costs, initial equity in drawdown, chronological development/validation/untouched test, dependence-aware uncertainty and recorded failed trials. Don't use NQ/CFDs/adjusted lines as MNQ fill substitutes.

Before any outcome calculation, freeze dataset hashes and exact full-session date boundaries, rule/code hashes, engine/version, decision/dispatch latencies, spread/friction assumptions, market/stop gap fills, target queue/trade-through, rejects/non-fills and marked-equity accounting. NautilusTrader remains the final-replay research candidate; a bar-only signal study cannot certify quote-execution fidelity. No engine or broker adapter is installed or activated in this task.

Keep the original earliest60%/next20%/sealed20% chronological convention after usable sessions are enumerated. Whole sessions remain together. Walk-forward selection stays inside development/validation; use purging for overlapping horizons and never train on later dates. If data is scarce, report insufficiency, not relaxed acceptance thresholds. For this expansion, explicitly apply the inherited multi-year and at-least200 OOS-trades/100-distinct-sessions sufficiency convention to each side/window proposed for adoption AND to the composite. This is a conservative research choice made before outcomes, not a universal statistical guarantee. It may be unattainable with currently available MNQ history or a rare signal; report inconclusive, rather than loosen rules to manufacture daily eligibility. Passing pooled results cannot approve an unsupported losing or undersampled side/window. Report the composite and every stratum; don't select a convenient subset after viewing the sealed results. Any later subset selection or changed sufficiency convention is a separately registered version needing new untouched evaluation.

The existing net expectancy with day/block-bootstrap lower bound above zero, base PF>=1.20, stressed PF>1, parameter robustness and risk/causality checks remain requirements. Stress nearby settings only on development data and register every variation. PBO/DSR, where estimable from comparable trials, are diagnostic and do not fix missing data or a reused holdout. No performance score alone certifies an edge.

After a reviewed historical pass on a matching frozen version, a versioned paper policy/helper and active setup review may qualify a forward pilot only within the actual human authorization established in the current Claude session. This download transfers no order authority. The forward operational review then needs at least30 completed round-trips over20 sessions, whichever takes longer. Do not require forward fills before the initial historically reviewed pilot, manufacture results to unlock it, or treat either stage as funded/live authorization.

## Measure daily coverage honestly

Report counts and denominators separately: all calendar sessions; full usable-data sessions; signal sessions; risk-affordable sessions; all-gates-qualified sessions; submitted-entry sessions; filled-entry sessions; blocked/no-trade sessions by reason. A missing-data day is unknown/rejected data, not a profitable zero-risk result. Keep valid no-signal days in the return/equity series when data and exits are complete.

For each stratum and the composite report eligible/skip days, attempted and filled orders, net expectancy in USD/R, win-rate uncertainty, average win/loss, PF, costs, daily marked equity, drawdown, worst loss, tails, exposure and dependence. Coverage is a descriptive result, never an optimization target that outranks expectancy/risk. A method trading more often can lose more after costs.

## Routine without a new automation

On an active session: check account/data/calendar and pre-session levels, evaluate the morning cohorts, then independently assess the afternoon cohort if available and flat. Record TRADE_CANDIDATE, NO_SIGNAL, INVALIDATED, CONFLICT, EXPOSURE_BLOCKED, RISK_SKIP, CALENDAR_SKIP, DATA_WAIT or VALIDATION_WAIT with evidence timestamps. A candidate is not a submitted order/fill.

Any separately authorized scheduled checks remain observation/recordkeeping only, with quiet notifications unless material change; this portable package installs no schedule. This document neither adds a schedule nor creates continuous supervision or unattended order execution. No guarantee of any entry or profit per day is made.
