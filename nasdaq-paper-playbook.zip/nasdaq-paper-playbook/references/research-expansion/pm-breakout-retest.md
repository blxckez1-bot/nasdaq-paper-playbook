# MNQ-R15-BRT-PM-v0.1

## Identity and hypothesis

Defined 26 October 2026. **SPECIFIED / UNVALIDATED / RESEARCH ONLY.** CME dated MNQ, standard five-minute OHLCV; one contract maximum. This is the separately registered afternoon cohort of the new breakout/retest family. The hypothesis is that a first successful retest following a break of a fixed afternoon reference interval may continue toward one interval-width extension. **13:00 is a chosen research anchor, not an exchange opening or a literature-proven optimal time.**

All [common rules](common-rules.md) apply. Long and short are separate strata. This is not the literature's 15:30–16:00 closing-momentum strategy and does not inherit that strategy's evidence.

## Entry rules

- Reference range is exactly the three bars covering 13:00:00–13:15:00 America/New_York, ending 13:05, 13:10 and 13:15. Freeze H, L, W and B only after the final bar closes and is available.
- Eligible first-breakout bars end from 13:20 through 14:45 inclusive.
- Use the first qualifying directional breakout and first touch in its next three consecutive five-minute bars under the common rules. A failed first touch, missing bar or invalidation exhausts this PM cohort; do not reverse or restart it after inspecting the outcome.
- The pre-submit event, submission and fill must all be strictly before 15:25, with recorded decision/dispatch latency. A late fill is retained as an execution deviation, not removed retrospectively.
- Observe the then-current account before any later eligible paper review. A morning loss or earlier profit never increases afternoon size or resets account-day losses. An existing position/pending entry blocks overlap.

## Exits

Retest-based structural stop and one-width target capped by frozen obstacles, with at least 2 net reward/risk before submission. No partial exits, trailing stop, averaging down, discretionary signal exit or widening an active stop.

Hard stop wins unresolved ordering ambiguity. Exit remaining hypothetical exposure at the first executable event at/after 15:30, with costs. No overnight or weekend exposure. Missing exit data is a simulation failure; target touch alone is not fill evidence. These research exits grant no authority to scheduled checks.

## Sizing and filters

Common one-MNQ/one-position and 0.10% cost-aware sizing apply. Do not tighten a structural stop for affordability. Normal full cash sessions and complete same-contract reference/overnight/warm-up data are required. Also freeze the completed 09:30–13:00 high and low as extra obstacles at the breakout's availability event; this excludes the new reference interval itself. No final-day extrema or full-session volume are available features.

No entry when a listed high-impact event lies anywhere in the intended entry-to-15:30 interval inclusive, or entry is within the original ten-minute event buffer. This may exclude a substantial portion of FOMC afternoons. Do not shorten the planned holding interval or omit an inconvenient event to pass the screen.

## Evaluation, dependencies and lifecycle

Apply [validation-and-selection.md](validation-and-selection.md) and the original chronological, cost, uncertainty and risk criteria. PM-long and PM-short are separately registered new trials; a profitable morning result cannot approve them. Usable data, historical replay, tested engine configuration and implementation are pending. No performance, win probability or daily-entry rate is established.

Failure modes include low participation, false breaks, late exhaustion, major announcements, costs, unaffordable stops and insufficient room to a nearby morning extreme. Retire/revise only with a new version and fresh evaluation. Version 0.1 is the initial research convention; no account order or existing strategy is altered.
