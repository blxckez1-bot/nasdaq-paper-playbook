# New breakout/retest family — common rules v0.1

26 October 2026. Applies to AM and PM documents in this bundle only. It neither changes SR-HL-LONG-v0.2 nor the separate old ORB-15-v0.1 control. **This family's target gate is net 2R; the old control retains its own gross-2R target and whole-range stop.**

## Data and causal availability

One actual dated MNQ contract; USD2/index point, tick 0.25 point (USD0.50). The [exchange specification](https://www.cmegroup.com/markets/equities/nasdaq/micro-e-mini-nasdaq-100.contractSpecs.html) defines these economics. Raw per-contract execution prices are required. NQ, CFDs, stock prices and hindsight-adjusted continuous prices do not substitute for MNQ fills or levels.

Use the original strategy's full-day calendar, same-contract prior cash session and overnight requirements. UTC storage, America/New_York rule clock, Europe/Copenhagen display. Bars have explicit start/end/known-at times; receive availability cannot precede bar end. Unresolved gaps, corrections, roll mapping or missing reference data block the cohort. Do not synthesize empty bars across outages.

ATR and warm-up inherit the frozen v0.2 convention: electronic-session standard five-minute bars on this contract, Wilder ATR14, first history TR=high-low, subsequent TR=max(high-low,abs(high-previous_close),abs(low-previous_close)); seed mean of first 14 TRs, then (13*previousATR+TR)/14. Require at least 250 completed bars and retain the exact warm-up start/hash. At reference-range end use the just-completed final range bar's available ATR. Freeze `B=ceil_tick(max(0.50,0.10*ATR))`; `ceil_tick(x)=ceil(x/0.25)*0.25`, and `floor_tick` is analogous.

## First breakout, first retest

1. At range-end availability freeze `H=max(range highs)`, `L=min(range lows)`, `W=H-L` and B. Reject `W<=0`. Require all three range bars; do not recompute range endpoints after the break.
2. Within the cohort's allowed bar-end window take the **first** completed bar b with `close>=H+0.25` (LONG) or `close<=L-0.25` (SHORT). This fixes direction. A range failure, rejected first breakout or its later failed setup never permits a new direction/second breakout in that cohort that day.
3. Inspect only b+1, b+2, b+3 in order. Missing any needed next bar blocks the candidate. Invalidation has priority on each completed bar before a touch or confirmation can qualify:
   - LONG invalidates on `close<H-B` OR `low<=L+B`.
   - SHORT invalidates on `close>L+B` OR `high>=H-B`.
4. The first LONG touch has `low<=H+B`; it qualifies only if `close>=H+0.25`, `close>open`, `low>L+B` and no invalidation. The first SHORT touch has `high>=L-B`; it qualifies only if `close<=L-0.25`, `close<open`, `high<H-B` and no invalidation. A failed first touch rejects the cohort, even if a second touch later looks better. No touch within the three bars means no signal.
5. Retest r is known only when it closes and arrives. Do not assign a fill at r's close or at a midpoint it touched earlier. After declared decision latency, observe the next executable quote: E0=ask for LONG, bid for SHORT. Submission/dispatch then precedes a later execution event. A preliminary next-bar model must explicitly label its omitted quote/latency limitations and cannot establish final execution fidelity.

## Stop and frozen target room

LONG stop `S=floor_tick(r.low-B)`; SHORT stop `S=ceil_tick(r.high+B)`. Do not change this to a whole-range or arbitrary tight stop to produce a better result.

At b availability freeze this finite obstacle set: prior completed cash-session high/low, overnight high/low over [18:00 on the preceding calendar day,09:30 today), and last two confirmed 15-minute pivot highs and last two lows then known. PM also includes completed 09:30–13:00 high/low. An interval is included only when expected data are complete; unknown required coverage blocks the test.

Pivots use standard 15-minute full electronic-session history aligned on local :00/:15/:30/:45. A pivot high is strictly higher than the highs of two bars on each side; low uses strict lower-than. It becomes available only after the second right-hand bar closes/arrives. Fewer than two existing confirmed pivots is a documented empty/partial pivot set when the required history is otherwise complete, not a license to invent levels. The original v0.2 handling remains unchanged.

At E0 choose the nearest frozen obstacle R strictly above a LONG entry or U strictly below a SHORT entry:

- LONG `T=floor_tick(min(H+W,R-B))`; without such R, use `floor_tick(H+W)`.
- SHORT `T=ceil_tick(max(L-W,U+B))`; without such U, use `ceil_tick(L-W)`.

Require LONG `S<E0<T` and `E0>H`; SHORT `T<E0<S` and `E0<L`. Freeze T at this observation; don't discard an inconvenient obstacle, use a later extreme, move T farther after fill or assume the extension has any known reach probability.

## Cost-aware contract sizing

Let C be the declared round-trip fee plus friction reserve per contract, at least USD15 for planning in this first version. Separate fees and unembedded entry/exit friction. A quoted ask/bid already embeds one side's spread; don't count that paid component again. USD15 is an assumption for stress planning, not a verified charged fee or loss guarantee.

`loss=2*abs(E0-S)+C`; `net_reward=2*abs(T-E0)-C`.

Require `net_reward>=2*loss` and `contracts=min(1,floor(fresh_equity*0.001/loss))>=1`, plus independent collateral and available-funds checks. Otherwise skip; no risk increase to meet a daily trade target. Actual realized PnL uses actual fills and explicit fees; don't subtract the planning reserve again when its friction is embedded in fills.

For historical testing, fresh_equity means that simulation ledger's own marked equity known at its pre-submit event. Freeze each ledger's initial equity, cashflows and full marked path in the manifest. Independent shadow ledgers cannot borrow the composite's equity or today's paper-account balance. Actual paper trading uses its freshly observed actual equity. Simulated equity/results never overwrite or reset the actual paper journal.

Synthetic arithmetic example: at equity USD100,000, the 0.10% budget is USD100. With a USD15 reserve a tick-aligned 42.5-point stop risks USD100 modeled; a 42.75-point stop risks USD100.50 and fails. A 42.5-point stop requires 107.5 points of target distance to meet net2R with the same reserve. These are synthetic numbers, not an account observation or a stop to force onto a chart.

## Shared operational gates and exit semantics

Require timely verified quotes, visible expected Paper Trading account, dated contract/expiry, fresh equity and reconciled positions/pending orders/cashflows, correct calendar, usable spread/liquidity/volatility evidence, cost calibration, active supervision and native full-quantity protective-stop/target plan. At most one MNQ position, no averaging down or wider stop. Fresh account/quote conventions remain those in the existing policy: 60/30 seconds. A ten-minute-delayed chart fails timely-quote confirmation for these short-term candidates.

Keep the original 2.5% account-day marked-equity review trigger, all prior tighter-review history and original baselines. A new date, cohort, version or short trade doesn't erase losses or establish a new daily opening balance. No new weekly/drawdown number is silently invented; use the existing documented account limits, or WAIT when unresolved.

The original event list and ten-minute entry buffer apply: CPI/PPI, Employment Situation, JOLTS, GDP, Personal Income and Outlays/PCE, retail sales, ISM manufacturing/services, US S&P Global flash/final PMI, Michigan preliminary/final sentiment, FOMC decision/press conference. Reject new entry when one falls anywhere in the entire intended holding interval through the cohort's flat time, or within ten minutes before/after entry. Use actual dated publication timestamps and calendar vintage; tag other releases and major Nasdaq earnings. Missing calendar or supervision means WAIT.

Preserve every submitted/filled event. Recompute risk and net reward from actual/model fill F, explicit fees and remaining unembedded exit friction. A fill on the wrong side of S/T, after the cutoff, over budget or below the new family's net2R threshold is a retained execution deviation, exited at the next executable event under the frozen model. Already-triggered stops take priority. Never relabel a filled loss as a pre-submit skip.

Use an explicitly registered adverse gap/stop model, target trade-through/queue/non-fill assumptions, fee schedule and decision/dispatch latency. In unresolved same-bar stop/target ambiguity use finer data or adverse ordering and flag it. No target before entry, no hypothetical stop-at-S through a gap, no zero-cost or instantaneous-fill default.

All these are future research/account-review requirements, not order authority. TradingView Desktop, the declined purchase, paper-only scope and scheduled observation-only checks are unchanged. The existing offline preflight is bound to the old long-only specification; it cannot qualify these new IDs, shorts or time windows. A reviewed, versioned extension of its policy/implementation and tests is required before later eligible paper use.
