# Broader daily coverage: research only

This separately registered research roadmap preserves the long sweep/reclaim default and adds four independent breakout/retest strata: AM long, AM short, PM long, PM short. A combined first-qualified selection rule is a fifth separately assessed configuration, not a claim about the total lifetime trial count.

| Cohort | Reference interval (New York) | Breakout bar ends | Entry before | Flat |
|---|---|---|---|---|
| AM | 09:30-09:45 | 09:50-10:30 inclusive | 10:55 | 11:00 |
| PM | 13:00-13:15 | 13:20-14:45 inclusive | 15:25 | 15:30 |

PM's anchor is a research choice, not a second exchange opening. All cohorts remain SPECIFIED/UNVALIDATED, with no acquired dataset, signal implementation, historical replay, win rate or profit evidence shipped in this package. The original long-only helper cannot qualify new cohort IDs or shorts. No daily trade minimum or new supervision/schedule is created.

Read [AM](am-breakout-retest.md), [PM](pm-breakout-retest.md), [shared rules](common-rules.md), [validation/selection](validation-and-selection.md), [registry](registry.json) and the [blank daily review](daily-review-template.json). The portable registry has no account binding and no current quote observation.
