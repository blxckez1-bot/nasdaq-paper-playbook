"""Offline MNQ proposal checks. No network, broker, UI or order authorization."""
import argparse
import hashlib
from datetime import datetime, timezone, time, date
from fractions import Fraction
import json
import re
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

CHECKS = ("correct_account", "contract_specs", "cash_calendar",
          "news_and_holding_window_clear", "higher_timeframe_context", "causal_signal",
          "frozen_resistance", "volatility_liquidity_spread", "costs_not_double_counted",
          "collateral", "account_day_review_clear", "prior_review_resolved",
          "native_protection_plan", "active_supervision", "paper_scope")


def timestamp(value):
    if not isinstance(value, str):
        raise ValueError("Missing timestamp")
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError("Naive timestamp")
    return result.astimezone(timezone.utc)


def number(value):
    if isinstance(value, bool) or value is None:
        raise ValueError("Missing numeric value")
    return Fraction(str(value))


def evaluate(snapshot, policy, now=None):
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("Current time must be timezone aware")
    now = now.astimezone(timezone.utc)
    reasons = []
    def block(code):
        if code not in reasons:
            reasons.append(code)
    if not isinstance(snapshot, dict):
        snapshot = {}
        block("malformed_snapshot")
    def field(key):
        value = snapshot.get(key)
        if not isinstance(value, dict):
            block("malformed_or_missing:" + key)
            return {}
        return value
    if snapshot.get("mode") != "active":
        block("observation_or_research_only")
    validation = policy.get("validation", {})
    if (validation.get("status") not in {"HISTORICAL_REVIEW_COMPLETE_PAPER_PILOT",
                                          "FORWARD_REVIEW_COMPLETE_PAPER_CONTINUATION"}
            or not validation.get("reviewed_report")
            or validation.get("validated_spec_sha256") != policy.get("strategy_sha256")):
        block("strategy_not_validated")
    symbol_match = re.fullmatch(r"CME_MINI:MNQ([HMUZ])(20\d{2})", str(snapshot.get("symbol", "")))
    if not symbol_match:
        block("not_a_dated_mnq_contract")
    if snapshot.get("direction") != "LONG":
        block("direction_outside_frozen_version")
    try:
        local = now.astimezone(ZoneInfo("America/New_York"))
        if local.weekday() >= 5 or not time(9, 35) <= local.time().replace(tzinfo=None) < time(10, 55):
            block("outside_entry_session")
    except ZoneInfoNotFoundError:
        block("timezone_database_unavailable")
    account = field("account")
    if account.get("mode") != "Paper Trading":
        block("paper_account_not_verified")
    expected_account = policy.get("expected_account")
    if not isinstance(expected_account, str) or not expected_account.strip():
        block("paper_account_not_configured")
    elif account.get("id") != expected_account:
        block("expected_paper_account_not_verified")
    if type(account.get("positions")) is not int or account.get("positions") != 0:
        block("existing_or_unknown_exposure")
    if type(account.get("pending_orders")) is not int or account.get("pending_orders") != 0:
        block("pending_or_unknown_orders")
    try:
        age = (now - timestamp(account.get("observed_at"))).total_seconds()
        if not 0 <= age <= policy["max_account_age_seconds"]:
            block("account_snapshot_stale_or_future")
    except (ValueError, TypeError, KeyError, OverflowError):
        block("account_timestamp_missing_or_invalid")
    quote = field("quote")
    if quote.get("real_time") is not True or quote.get("delay_seconds") != 0 or isinstance(quote.get("delay_seconds"), bool):
        block("timely_quotes_not_verified")
    for key in ("observed_at", "market_timestamp"):
        try:
            age = (now - timestamp(quote.get(key))).total_seconds()
            if not 0 <= age <= policy["max_quote_age_seconds"]:
                block("quote_stale_or_future")
        except (ValueError, TypeError, KeyError, OverflowError):
            block("quote_timestamp_missing_or_invalid")
    try:
        if timestamp(quote.get("market_timestamp")) > timestamp(quote.get("observed_at")):
            block("market_timestamp_after_observation")
    except (ValueError, TypeError, OverflowError):
        pass
    checks = field("checks")
    for key in CHECKS:
        check = checks.get(key)
        if (not isinstance(check, dict) or check.get("verified") is not True or not isinstance(check.get("evidence"), str)
                or not check["evidence"].strip()):
            block("evidence_missing:" + key)
    plan = field("plan")
    arithmetic = None
    try:
        expiry = date.fromisoformat(plan.get("contract_expiry"))
        if expiry <= now.date():
            block("contract_expired_or_expiry_day")
        if symbol_match and (expiry.year != int(symbol_match.group(2))
                or expiry.month != {"H": 3, "M": 6, "U": 9, "Z": 12}[symbol_match.group(1)]):
            block("symbol_expiry_mismatch")
    except (ValueError, TypeError):
        block("expiry_missing_or_invalid")
    try:
        equity = number(account.get("equity"))
        bid, ask = number(quote.get("bid")), number(quote.get("ask"))
        entry, stop, target = [number(plan.get(k)) for k in ("entry_reference", "stop", "target")]
        reserve = number(plan.get("cost_reserve_per_contract_usd"))
        if min(equity, bid, ask, entry, stop, target) <= 0 or ask < bid:
            raise ValueError("Invalid equity/quote/prices")
        tick = number(policy["tick_points"])
        if any((x / tick).denominator != 1 for x in (bid, ask, entry, stop, target)):
            block("price_off_tick_grid")
        if not stop < entry < target:
            block("invalid_stop_target_direction")
        if entry != ask:
            block("entry_reference_not_current_ask")
        if reserve < number(policy["minimum_stress_reserve_usd"]):
            block("cost_reserve_below_current_policy")
        if stop < entry < target and reserve >= 0:
            multiplier = number(policy["usd_per_point"])
            budget = equity * number(policy["planning_risk_pct"]) / 100
            loss = (entry - stop) * multiplier + reserve
            reward = (target - entry) * multiplier - reserve
            quantity = min(policy["maximum_contracts"], budget // loss)
            if quantity < 1:
                block("one_contract_exceeds_budget")
            if reward < number(policy["minimum_net_reward_risk"]) * loss:
                block("insufficient_cost_adjusted_target_room")
            arithmetic = {"budget_usd": float(budget), "modeled_loss_per_contract_usd": float(loss),
                          "modeled_reward_per_contract_usd": float(reward),
                          "cost_adjusted_reward_risk": float(reward / loss),
                          "contracts_by_budget": int(quantity), "reserve_is_actual_fee": False,
                          "maximum_loss_guaranteed": False}
    except (ValueError, TypeError, KeyError, ZeroDivisionError, OverflowError):
        block("numeric_plan_missing_or_invalid")
    return {"schema_version": "1.0", "checked_at_utc": now.isoformat(),
            "strategy_id": policy["strategy_id"], "strategy_sha256": policy["strategy_sha256"],
            "status": "WAIT" if reasons else "PAPER_PLAN_REVIEWABLE",
            "blocking_reasons": reasons, "arithmetic": arithmetic,
            "signal_detected_by_script": False, "external_evidence_verified_by_script": False,
            "order_authorized": False, "orders_submitted": 0,
            "meaning": "Local proposal checks only; no market edge or broker permission is certified"}


def read_json(path):
    def reject(value):
        raise ValueError("Non-finite JSON constant: " + value)
    result = json.loads(Path(path).read_text(encoding="utf-8-sig"), parse_constant=reject)
    if not isinstance(result, dict):
        raise ValueError("A JSON object is required")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    skill_root = Path(__file__).resolve().parent.parent
    output = Path(args.output).resolve()
    try:
        output.relative_to(skill_root)
    except ValueError:
        pass
    else:
        raise ValueError("Decision output cannot overwrite any installed skill resource")
    if output.exists():
        raise FileExistsError("Choose a new decision file; existing files are never overwritten")
    policy_path = skill_root / "references" / "operating-policy.json"
    policy = read_json(policy_path)
    spec_path = policy_path.parent / "strategy-v0.2.md"
    if hashlib.sha256(spec_path.read_bytes()).hexdigest() != policy["strategy_sha256"]:
        raise ValueError("Installed specification hash mismatch; review the changed version")
    invalid_input = False
    try:
        snapshot = read_json(args.snapshot)
    except (ValueError, TypeError, OSError, OverflowError):
        snapshot = {}
        invalid_input = True
    result = evaluate(snapshot, policy)
    if invalid_input:
        result["blocking_reasons"].insert(0, "snapshot_file_missing_or_invalid")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(result["status"] + ": " + ", ".join(result["blocking_reasons"]))


if __name__ == "__main__":
    main()
